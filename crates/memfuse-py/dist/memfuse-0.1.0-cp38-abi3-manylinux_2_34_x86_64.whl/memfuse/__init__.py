from .memfuse import *

__doc__ = memfuse.__doc__
if hasattr(memfuse, "__all__"):
    __all__ = memfuse.__all__